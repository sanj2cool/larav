Dear {{ $name }}
This is your reminder for the event at {{ $schedule_time }}

[
Please confirm you will be attending
YES
Sorry I cant - will someone swap with me 
]

Thanks
Reminder Buoy